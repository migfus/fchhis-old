import{_ as c,b as e,c as t}from"./app-app2.js";const n={};function o(r,s){return e(),t("div",null,"Account Settings")}const _=c(n,[["render",o]]);export{_ as default};
